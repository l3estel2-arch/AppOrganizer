package com.thai.apporganizer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/** หน้าจอหลัก: แสดงแอปเป็นโฟลเดอร์ตามหมวดหมู่ที่ผู้ใช้ยืนยันแล้ว */
public class MainActivity extends Activity {

    private static final int REQ_REVIEW = 1001;
    private static final String UNSORTED = "ยังไม่จัดหมวด";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private OrganizerStore store;
    private TextView summaryText;
    private TextView banner;
    private FrameLayout content;
    private AlertDialog openDialog;

    private boolean scanning = false;
    private boolean pendingRescan = false;
    private List<AppEntry> apps = new ArrayList<>();
    private final List<Folder> folders = new ArrayList<>();

    private static final class Folder {
        final String name;
        final boolean unsorted;
        final List<AppEntry> apps = new ArrayList<>();

        Folder(String name, boolean unsorted) {
            this.name = name;
            this.unsorted = unsorted;
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new OrganizerStore(this);
        setContentView(buildLayout());
        Ui.setupWindow(this);
        showLoading();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        dismissOpenDialog();
    }

    @Override
    protected void onDestroy() {
        dismissOpenDialog();
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // ถ้าตั้งเป็นหน้าจอหลักแล้ว ปุ่มย้อนกลับไม่ควรปิดหน้าจอหลัก
        if (!isDefaultHome()) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_REVIEW && resultCode == RESULT_OK) {
            Toast.makeText(this, "จัดระเบียบเรียบร้อยแล้ว", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- layout

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        Ui.applyInsets(root, Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 8));

        TextView title = Ui.text(this, "แอปของฉัน", 26, Ui.TEXT, true);
        root.addView(title);

        summaryText = Ui.text(this, "", 14, Ui.MUTED, false);
        summaryText.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 10));
        root.addView(summaryText);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button summaryBtn = Ui.button(this, "สรุปแอป", false);
        summaryBtn.setOnClickListener(v -> showSummary());
        Button reorganizeBtn = Ui.button(this, "จัดระเบียบใหม่", true);
        reorganizeBtn.setOnClickListener(v -> startReview());
        Button homeBtn = Ui.button(this, "ตั้งเป็นหน้าจอหลัก", false);
        homeBtn.setOnClickListener(v -> openHomeSettings());

        addAction(actions, reorganizeBtn);
        addAction(actions, summaryBtn);
        addAction(actions, homeBtn);
        hs.addView(actions);
        root.addView(hs);

        banner = Ui.text(this, "", 14, Ui.TEXT, true);
        int p = Ui.dp(this, 12);
        banner.setPadding(p, p, p, p);
        banner.setBackground(Ui.pressable(Ui.round(0xFFFBE9D8, Ui.dp(this, 14))));
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(v -> startReview());
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(this, 12);
        root.addView(banner, blp);

        content = new FrameLayout(this);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        clp.topMargin = Ui.dp(this, 12);
        root.addView(content, clp);
        return root;
    }

    private void addAction(LinearLayout row, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(this, 8);
        row.addView(b, lp);
    }

    private void showLoading() {
        content.removeAllViews();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.addView(new ProgressBar(this));
        TextView t = Ui.text(this, "กำลังสแกนแอปในเครื่อง…", 15, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(this, 12), 0, 0);
        box.addView(t);
        content.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        summaryText.setText("กำลังโหลด…");
    }

    // ---------------------------------------------------------------- data

    private void refresh() {
        if (scanning) {
            pendingRescan = true;
            return;
        }
        scanning = true;
        try {
            executor.execute(() -> {
                List<AppEntry> result;
                try {
                    result = AppRepository.scan(getApplicationContext());
                } catch (RuntimeException e) {
                    result = new ArrayList<>();
                }
                final List<AppEntry> res = result;
                mainHandler.post(() -> {
                    scanning = false;
                    if (isFinishing() || isDestroyed()) return;
                    apps = res;
                    render();
                    if (pendingRescan) {
                        pendingRescan = false;
                        refresh();
                    }
                });
            });
        } catch (RejectedExecutionException e) {
            scanning = false;
        }
    }

    private void buildFolders() {
        folders.clear();
        List<String> cats = store.loadCategories();
        Map<String, String> assign = store.loadAssignments();
        Map<String, Folder> byName = new LinkedHashMap<>();
        for (String c : cats) byName.put(c, new Folder(c, false));
        Folder unsorted = new Folder(UNSORTED, true);

        for (AppEntry app : apps) {
            String c = OrganizerStore.lookup(assign, app);
            Folder f = c == null ? null : byName.get(c);
            if (f != null) f.apps.add(app);
            else unsorted.apps.add(app);
        }
        for (Folder f : byName.values()) {
            if (!f.apps.isEmpty()) folders.add(f);
        }
        if (!unsorted.apps.isEmpty()) folders.add(unsorted);
    }

    private int unsortedCount() {
        for (Folder f : folders) if (f.unsorted) return f.apps.size();
        return 0;
    }

    private void render() {
        dismissOpenDialog();
        content.removeAllViews();

        if (!store.isApplied()) {
            summaryText.setText("พบแอปในเครื่อง " + apps.size() + " แอป · ยังไม่ได้จัดระเบียบ");
            banner.setVisibility(View.GONE);
            renderWelcome();
            return;
        }

        buildFolders();
        int realFolders = 0;
        for (Folder f : folders) if (!f.unsorted) realFolders++;
        summaryText.setText("แอปทั้งหมด " + apps.size() + " แอป · " + realFolders + " โฟลเดอร์");

        int newCount = unsortedCount();
        if (newCount > 0) {
            banner.setText("มีแอปใหม่ " + newCount + " แอปที่ยังไม่ได้จัดหมวด — แตะเพื่อตรวจสอบและยืนยัน");
            banner.setVisibility(View.VISIBLE);
        } else {
            banner.setVisibility(View.GONE);
        }

        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(Ui.dp(this, 16));
        grid.setHorizontalSpacing(Ui.dp(this, 8));
        grid.setSelector(new ColorDrawable(0x00000000));
        grid.setClipToPadding(false);
        grid.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 16));
        grid.setAdapter(new FolderAdapter());
        grid.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < folders.size()) openFolder(folders.get(position));
        });
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < folders.size()) {
                Folder f = folders.get(position);
                if (!f.unsorted) renameFolder(f.name);
            }
            return true;
        });
        content.addView(grid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void renderWelcome() {
        ScrollView sv = new ScrollView(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        card.setPadding(p, p, p, p);
        card.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 20)));

        card.addView(Ui.text(this, "จัดแอปให้เป็นระเบียบ", 20, Ui.TEXT, true));
        TextView body = Ui.text(this,
                "แอปนี้จะสแกนแอปทั้งหมดในเครื่อง (" + apps.size() + " แอป) แล้วเสนอการจัดเป็นโฟลเดอร์ตามหมวดหมู่ "
                        + "เช่น การเงินและธนาคาร, โซเชียลและแชท, ช้อปปิ้ง, อาหารและเดลิเวอรี่\n\n"
                        + "คุณจะได้เห็นสรุปและตรวจสอบทุกแอปก่อน ย้ายหมวดหรือเปลี่ยนชื่อโฟลเดอร์ได้ "
                        + "ระบบจะยังไม่เปลี่ยนอะไรจนกว่าคุณจะกด \"ยืนยัน\"",
                15, Ui.MUTED, false);
        body.setLineSpacing(0, 1.2f);
        body.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 16));
        card.addView(body);

        Button start = Ui.button(this, "สแกนแอปและเสนอหมวดหมู่", true);
        start.setOnClickListener(v -> startReview());
        card.addView(start, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        sv.addView(card);
        content.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ---------------------------------------------------------------- adapters

    private final class FolderAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return folders.size();
        }

        @Override
        public Object getItem(int position) {
            return folders.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Folder f = folders.get(position);
            LinearLayout tile = new LinearLayout(MainActivity.this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER_HORIZONTAL);

            int boxSize = Ui.dp(MainActivity.this, 84);
            FrameLayout box = new FrameLayout(MainActivity.this);
            GradientDrawable bg = Ui.round(f.unsorted ? 0xFFFBE9D8 : Ui.CARD, Ui.dp(MainActivity.this, 22));
            if (f.unsorted) {
                bg.setStroke(Ui.dp(MainActivity.this, 2), Ui.BADGE,
                        Ui.dp(MainActivity.this, 6), Ui.dp(MainActivity.this, 4));
            }
            box.setBackground(bg);
            box.setElevation(Ui.dp(MainActivity.this, 2));

            GridLayout mini = new GridLayout(MainActivity.this);
            mini.setColumnCount(2);
            int iconSize = Ui.dp(MainActivity.this, 28);
            int m = Ui.dp(MainActivity.this, 3);
            int n = Math.min(4, f.apps.size());
            for (int i = 0; i < n; i++) {
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(Ui.copyIcon(MainActivity.this, f.apps.get(i).icon));
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = iconSize;
                lp.height = iconSize;
                lp.setMargins(m, m, m, m);
                mini.addView(iv, lp);
            }
            box.addView(mini, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
            tile.addView(box, new LinearLayout.LayoutParams(boxSize, boxSize));

            TextView name = Ui.text(MainActivity.this, f.name, 13, Ui.TEXT, true);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setPadding(0, Ui.dp(MainActivity.this, 6), 0, 0);
            tile.addView(name, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView count = Ui.text(MainActivity.this, f.apps.size() + " แอป", 11, Ui.MUTED, false);
            count.setGravity(Gravity.CENTER);
            tile.addView(count, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return tile;
        }
    }

    private final class AppGridAdapter extends BaseAdapter {
        private final List<AppEntry> list;

        AppGridAdapter(List<AppEntry> list) {
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            AppEntry app = list.get(position);
            LinearLayout cell = new LinearLayout(MainActivity.this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            int p = Ui.dp(MainActivity.this, 4);
            cell.setPadding(p, p, p, p);

            ImageView iv = new ImageView(MainActivity.this);
            iv.setImageDrawable(Ui.copyIcon(MainActivity.this, app.icon));
            int s = Ui.dp(MainActivity.this, 48);
            cell.addView(iv, new LinearLayout.LayoutParams(s, s));

            TextView label = Ui.text(MainActivity.this, app.label, 12, Ui.TEXT, false);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setPadding(0, Ui.dp(MainActivity.this, 4), 0, 0);
            cell.addView(label, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return cell;
        }
    }

    // ---------------------------------------------------------------- actions

    private void openFolder(Folder f) {
        dismissOpenDialog();
        GridView g = new GridView(this);
        g.setNumColumns(4);
        g.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        g.setVerticalSpacing(Ui.dp(this, 10));
        int p = Ui.dp(this, 12);
        g.setPadding(p, p, p, p);
        g.setAdapter(new AppGridAdapter(f.apps));
        g.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < f.apps.size()) {
                launch(f.apps.get(position));
            }
        });
        g.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < f.apps.size()) appOptions(f.apps.get(position));
            return true;
        });

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(f.name + " (" + f.apps.size() + ")")
                .setView(g)
                .setPositiveButton("ปิด", null);
        if (f.unsorted) {
            b.setNeutralButton("ตรวจสอบและจัดหมวด", (d, w) -> startReview());
        }
        openDialog = b.create();
        openDialog.show();
    }

    private void appOptions(AppEntry app) {
        String[] items = {"เปิดแอป", "ย้ายไปหมวดอื่น", "ข้อมูลแอป (ถอนการติดตั้งได้ที่นี่)"};
        new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setItems(items, (d, which) -> {
                    if (which == 0) launch(app);
                    else if (which == 1) chooseMoveTarget(app);
                    else openAppInfo(app);
                })
                .show();
    }

    private void chooseMoveTarget(AppEntry app) {
        final List<String> cats = store.loadCategories();
        String[] items = new String[cats.size() + 1];
        for (int i = 0; i < cats.size(); i++) items[i] = cats.get(i);
        items[cats.size()] = "+ สร้างหมวดหมู่ใหม่…";
        new AlertDialog.Builder(this)
                .setTitle("ย้าย \"" + app.label + "\" ไปที่")
                .setItems(items, (d, which) -> {
                    if (which < cats.size()) {
                        confirmMove(app, cats.get(which));
                    } else {
                        askName("สร้างหมวดหมู่ใหม่", "", name -> confirmMove(app, name));
                    }
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void confirmMove(AppEntry app, String target) {
        new AlertDialog.Builder(this)
                .setTitle("ยืนยันการย้าย")
                .setMessage("ย้าย \"" + app.label + "\" ไปที่โฟลเดอร์ \"" + target + "\" ใช่หรือไม่?")
                .setPositiveButton("ยืนยัน", (d, w) -> {
                    List<String> cats = store.loadCategories();
                    Map<String, String> assign = store.loadAssignments();
                    if (!cats.contains(target)) cats.add(target);
                    // ล้างค่าเดิมของแพ็กเกจนี้ (กรณี key เปลี่ยน) แล้วกำหนดใหม่
                    String prefix = app.packageName + "/";
                    List<String> stale = new ArrayList<>();
                    for (String k : assign.keySet()) if (k.startsWith(prefix)) stale.add(k);
                    for (String k : stale) assign.remove(k);
                    assign.put(app.key, target);
                    store.save(cats, assign);
                    render();
                    Toast.makeText(this, "ย้ายเรียบร้อย", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void renameFolder(String oldName) {
        askName("เปลี่ยนชื่อโฟลเดอร์", oldName, newName -> {
            if (newName.equals(oldName)) return;
            List<String> cats = store.loadCategories();
            if (cats.contains(newName)) {
                Toast.makeText(this, "มีโฟลเดอร์ชื่อนี้อยู่แล้ว", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("ยืนยันการเปลี่ยนชื่อ")
                    .setMessage("เปลี่ยนชื่อ \"" + oldName + "\" เป็น \"" + newName + "\" ใช่หรือไม่?")
                    .setPositiveButton("ยืนยัน", (d, w) -> {
                        List<String> c2 = store.loadCategories();
                        Map<String, String> assign = store.loadAssignments();
                        int idx = c2.indexOf(oldName);
                        if (idx >= 0) c2.set(idx, newName);
                        for (Map.Entry<String, String> e : assign.entrySet()) {
                            if (oldName.equals(e.getValue())) e.setValue(newName);
                        }
                        store.save(c2, assign);
                        render();
                    })
                    .setNegativeButton("ยกเลิก", null)
                    .show();
        });
    }

    interface NameCallback {
        void onName(String name);
    }

    private void askName(String title, String initial, NameCallback cb) {
        final EditText edit = new EditText(this);
        edit.setText(initial);
        edit.setHint("ชื่อหมวดหมู่");
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(Ui.inputBox(this, edit))
                .setPositiveButton("ตกลง", (d, w) -> {
                    String name = edit.getText() == null ? "" : edit.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "กรุณาใส่ชื่อ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (name.length() > 40) name = name.substring(0, 40);
                    if (name.equals(UNSORTED)) {
                        Toast.makeText(this, "ชื่อนี้ใช้ไม่ได้", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    cb.onName(name);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void showSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("แอปทั้งหมด ").append(apps.size()).append(" แอป\n\n");
        if (!store.isApplied()) {
            Map<String, Integer> counts = new LinkedHashMap<>();
            for (String c : Categorizer.DEFAULT_ORDER) counts.put(c, 0);
            for (AppEntry a : apps) {
                Integer v = counts.get(a.suggested);
                counts.put(a.suggested, v == null ? 1 : v + 1);
            }
            sb.append("หมวดหมู่ที่ระบบเสนอ (ยังไม่ได้ยืนยัน):\n");
            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                if (e.getValue() > 0) sb.append("• ").append(e.getKey()).append(": ").append(e.getValue()).append(" แอป\n");
            }
        } else {
            sb.append("โฟลเดอร์ปัจจุบัน:\n");
            for (Folder f : folders) {
                sb.append("• ").append(f.name).append(": ").append(f.apps.size()).append(" แอป\n");
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("สรุปแอปในเครื่อง")
                .setMessage(sb.toString().trim())
                .setPositiveButton("ปิด", null)
                .setNeutralButton("จัดระเบียบ", (d, w) -> startReview())
                .show();
    }

    private void startReview() {
        dismissOpenDialog();
        startActivityForResult(new Intent(this, ReviewActivity.class), REQ_REVIEW);
    }

    private void launch(AppEntry app) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(new ComponentName(app.packageName, app.activityName));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
            dismissOpenDialog();
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "เปิดแอปนี้ไม่ได้ (อาจถูกถอนการติดตั้งแล้ว)", Toast.LENGTH_SHORT).show();
            refresh();
        }
    }

    private void openAppInfo(AppEntry app) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + app.packageName));
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "เปิดหน้าข้อมูลแอปไม่ได้", Toast.LENGTH_SHORT).show();
        }
    }

    private void openHomeSettings() {
        if (isDefaultHome()) {
            Toast.makeText(this, "แอปนี้เป็นหน้าจอหลักอยู่แล้ว", Toast.LENGTH_SHORT).show();
        }
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
                Toast.makeText(this, "ไปที่ แอป > แอปเริ่มต้น > หน้าจอหลัก", Toast.LENGTH_LONG).show();
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "เปิดการตั้งค่าไม่ได้", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean isDefaultHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        try {
            ResolveInfo ri = getPackageManager().resolveActivity(home, 0);
            return ri != null && ri.activityInfo != null
                    && getPackageName().equals(ri.activityInfo.packageName);
        } catch (RuntimeException e) {
            return false;
        }
    }

    private void dismissOpenDialog() {
        if (openDialog != null) {
            try {
                if (openDialog.isShowing()) openDialog.dismiss();
            } catch (RuntimeException ignored) {
                // หน้าต่างอาจถูกปิดไปแล้ว
            }
            openDialog = null;
        }
    }
}
