package com.thai.apporganizer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/**
 * หน้าตรวจสอบ: แสดงสรุปและหมวดหมู่ที่เสนอสำหรับทุกแอป
 * ผู้ใช้ย้ายหมวด / เปลี่ยนชื่อ / สร้างหมวดใหม่ได้ และจะบันทึกก็ต่อเมื่อกด "ยืนยัน" เท่านั้น
 */
public class ReviewActivity extends Activity {

    private static final String UNSORTED = "ยังไม่จัดหมวด";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private OrganizerStore store;
    private List<AppEntry> apps = new ArrayList<>();
    private final Map<String, String> work = new HashMap<>();
    private final List<String> cats = new ArrayList<>();
    private final Set<String> newKeys = new HashSet<>();
    private final List<Object> rows = new ArrayList<>();
    private boolean loaded = false;
    private boolean changed = false;

    private TextView summary;
    private ProgressBar progress;
    private ListView list;
    private RowAdapter adapter;
    private Button autoBtn, cancelBtn, confirmBtn;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new OrganizerStore(this);
        setContentView(buildLayout());
        Ui.setupWindow(this);
        setButtonsEnabled(false);
        load();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        askCancel();
    }

    // ---------------------------------------------------------------- layout

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        Ui.applyInsets(root, Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 8));

        root.addView(Ui.text(this, "ตรวจสอบก่อนจัดระเบียบ", 22, Ui.TEXT, true));

        summary = Ui.text(this, "กำลังสแกนแอปในเครื่อง…", 14, Ui.MUTED, false);
        summary.setLineSpacing(0, 1.15f);
        summary.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(summary);

        progress = new ProgressBar(this);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.topMargin = Ui.dp(this, 24);
        root.addView(progress, plp);

        list = new ListView(this);
        list.setDivider(new ColorDrawable(Ui.LINE));
        list.setDividerHeight(1);
        list.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 16)));
        list.setClipToOutline(true);
        list.setSelector(new ColorDrawable(0x00000000));
        adapter = new RowAdapter();
        list.setAdapter(adapter);
        list.setVisibility(View.GONE);
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(0, Ui.dp(this, 10), 0, 0);

        autoBtn = Ui.button(this, "จัดอัตโนมัติใหม่", false);
        autoBtn.setOnClickListener(v -> askAutoReset());
        cancelBtn = Ui.button(this, "ยกเลิก", false);
        cancelBtn.setOnClickListener(v -> askCancel());
        confirmBtn = Ui.button(this, "ยืนยัน", true);
        confirmBtn.setOnClickListener(v -> askConfirm());

        addBarButton(bar, autoBtn, 1.3f, true);
        addBarButton(bar, cancelBtn, 1f, true);
        addBarButton(bar, confirmBtn, 1.1f, false);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return root;
    }

    private void addBarButton(LinearLayout bar, Button b, float weight, boolean gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        if (gap) lp.rightMargin = Ui.dp(this, 8);
        bar.addView(b, lp);
    }

    private void setButtonsEnabled(boolean enabled) {
        autoBtn.setEnabled(enabled);
        confirmBtn.setEnabled(enabled);
        autoBtn.setAlpha(enabled ? 1f : 0.5f);
        confirmBtn.setAlpha(enabled ? 1f : 0.5f);
    }

    // ---------------------------------------------------------------- data

    private void load() {
        try {
            executor.execute(() -> {
                List<AppEntry> result;
                try {
                    result = AppRepository.scan(getApplicationContext());
                } catch (RuntimeException e) {
                    result = new ArrayList<>();
                }
                final List<AppEntry> res = result;
                mainHandler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    init(res);
                });
            });
        } catch (RejectedExecutionException e) {
            finish();
        }
    }

    private void init(List<AppEntry> scanned) {
        apps = scanned;
        work.clear();
        cats.clear();
        newKeys.clear();

        if (store.isApplied()) {
            List<String> savedCats = store.loadCategories();
            Map<String, String> saved = store.loadAssignments();
            cats.addAll(savedCats);
            for (AppEntry a : apps) {
                String c = OrganizerStore.lookup(saved, a);
                if (c != null && cats.contains(c)) {
                    work.put(a.key, c);
                } else {
                    work.put(a.key, a.suggested);
                    newKeys.add(a.key);
                }
            }
        } else {
            for (AppEntry a : apps) work.put(a.key, a.suggested);
        }
        ensureCategories();

        loaded = true;
        progress.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        setButtonsEnabled(!apps.isEmpty());
        rebuild();
    }

    /** ใส่หมวดที่ใช้อยู่แต่ยังไม่อยู่ในรายการ (เรียงตามลำดับเริ่มต้น) */
    private void ensureCategories() {
        Set<String> used = new HashSet<>(work.values());
        for (String c : Categorizer.DEFAULT_ORDER) {
            if (used.contains(c) && !cats.contains(c)) cats.add(c);
        }
        for (String c : used) {
            if (!cats.contains(c)) cats.add(c);
        }
    }

    private List<AppEntry> appsIn(String cat) {
        List<AppEntry> out = new ArrayList<>();
        for (AppEntry a : apps) if (cat.equals(work.get(a.key))) out.add(a);
        return out;
    }

    private Map<String, Integer> usedCounts() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (String c : cats) {
            int n = appsIn(c).size();
            if (n > 0) m.put(c, n);
        }
        return m;
    }

    private void rebuild() {
        rows.clear();
        for (String c : cats) {
            List<AppEntry> members = appsIn(c);
            if (members.isEmpty()) continue;
            rows.add(c);
            rows.addAll(members);
        }

        int folderCount = usedCounts().size();
        StringBuilder sb = new StringBuilder();
        if (apps.isEmpty()) {
            sb.append("ไม่พบแอปที่จะจัดระเบียบ");
        } else {
            sb.append("พบแอปทั้งหมด ").append(apps.size()).append(" แอป → จัดเป็น ")
                    .append(folderCount).append(" โฟลเดอร์");
            if (!newKeys.isEmpty()) {
                sb.append("\nแอปใหม่ที่ยังไม่เคยจัด ").append(newKeys.size()).append(" แอป (มีป้าย \"ใหม่\")");
            }
            sb.append("\nแตะที่แอปเพื่อย้ายหมวด · แตะ \"เปลี่ยนชื่อ\" ที่หัวข้อเพื่อตั้งชื่อโฟลเดอร์เอง");
        }
        summary.setText(sb.toString());
        adapter.notifyDataSetChanged();
    }

    // ---------------------------------------------------------------- adapter

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_APP = 1;

    private static final class HeaderHolder {
        TextView name;
        TextView count;
        Button rename;
    }

    private static final class AppHolder {
        ImageView icon;
        TextView label;
        TextView badge;
        TextView pkg;
        Button move;
    }

    private final class RowAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public int getItemViewType(int position) {
            return rows.get(position) instanceof String ? TYPE_HEADER : TYPE_APP;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return false; // จัดการคลิกเองในแต่ละแถว
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Object item = rows.get(position);
            if (item instanceof String) {
                View v = convertView != null && convertView.getTag() instanceof HeaderHolder
                        ? convertView : createHeader();
                bindHeader((HeaderHolder) v.getTag(), (String) item);
                return v;
            } else {
                View v = convertView != null && convertView.getTag() instanceof AppHolder
                        ? convertView : createAppRow();
                bindApp(v, (AppHolder) v.getTag(), (AppEntry) item);
                return v;
            }
        }
    }

    private View createHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(Ui.ACCENT_SOFT);
        int p = Ui.dp(this, 12);
        row.setPadding(p, Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        HeaderHolder h = new HeaderHolder();
        h.name = Ui.text(this, "", 16, Ui.ACCENT, true);
        h.name.setMaxLines(2);
        h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.count = Ui.text(this, "", 12, Ui.MUTED, false);
        texts.addView(h.name);
        texts.addView(h.count);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        h.rename = Ui.button(this, "เปลี่ยนชื่อ", false);
        h.rename.setTextSize(13);
        h.rename.setBackground(Ui.pressable(Ui.round(Ui.CARD, Ui.dp(this, 18))));
        h.rename.setMinHeight(Ui.dp(this, 36));
        h.rename.setMinimumHeight(Ui.dp(this, 36));
        row.addView(h.rename, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.setTag(h);
        return row;
    }

    private void bindHeader(HeaderHolder h, String cat) {
        h.name.setText("📁 " + cat);
        h.count.setText(appsIn(cat).size() + " แอป");
        h.rename.setOnClickListener(v -> askRename(cat));
    }

    private View createAppRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 12);
        row.setPadding(p, Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        row.setBackground(Ui.pressable(new ColorDrawable(Ui.CARD)));

        AppHolder h = new AppHolder();
        h.icon = new ImageView(this);
        int s = Ui.dp(this, 40);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(s, s);
        ilp.rightMargin = Ui.dp(this, 12);
        row.addView(h.icon, ilp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);

        LinearLayout line1 = new LinearLayout(this);
        line1.setOrientation(LinearLayout.HORIZONTAL);
        line1.setGravity(Gravity.CENTER_VERTICAL);
        h.label = Ui.text(this, "", 15, Ui.TEXT, false);
        h.label.setSingleLine(true);
        h.label.setEllipsize(TextUtils.TruncateAt.END);
        line1.addView(h.label, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        h.badge = Ui.text(this, "ใหม่", 11, 0xFFFFFFFF, true);
        int bp = Ui.dp(this, 6);
        h.badge.setPadding(bp, Ui.dp(this, 1), bp, Ui.dp(this, 1));
        h.badge.setBackground(Ui.round(Ui.BADGE, Ui.dp(this, 8)));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.leftMargin = Ui.dp(this, 6);
        line1.addView(h.badge, blp);
        texts.addView(line1);

        h.pkg = Ui.text(this, "", 11, Ui.MUTED, false);
        h.pkg.setSingleLine(true);
        h.pkg.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        texts.addView(h.pkg);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        h.move = Ui.button(this, "ย้าย", false);
        h.move.setTextSize(13);
        h.move.setMinHeight(Ui.dp(this, 36));
        h.move.setMinimumHeight(Ui.dp(this, 36));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.leftMargin = Ui.dp(this, 8);
        row.addView(h.move, mlp);
        row.setTag(h);
        return row;
    }

    private void bindApp(View row, AppHolder h, AppEntry app) {
        h.icon.setImageDrawable(Ui.copyIcon(this, app.icon));
        h.label.setText(app.label);
        h.badge.setVisibility(newKeys.contains(app.key) ? View.VISIBLE : View.GONE);
        h.pkg.setText(app.packageName);
        h.move.setOnClickListener(v -> askMove(app));
        row.setOnClickListener(v -> askMove(app));
    }

    // ---------------------------------------------------------------- actions

    private void askMove(AppEntry app) {
        final List<String> choices = new ArrayList<>(cats);
        String[] items = new String[choices.size() + 1];
        String current = work.get(app.key);
        int checked = -1;
        for (int i = 0; i < choices.size(); i++) {
            String c = choices.get(i);
            int n = appsIn(c).size();
            items[i] = c + "  (" + n + ")";
            if (c.equals(current)) checked = i;
        }
        items[choices.size()] = "+ สร้างหมวดหมู่ใหม่…";

        new AlertDialog.Builder(this)
                .setTitle("ย้าย \"" + app.label + "\" ไปที่")
                .setSingleChoiceItems(items, checked, (d, which) -> {
                    d.dismiss();
                    if (which < choices.size()) {
                        moveTo(app, choices.get(which));
                    } else {
                        askName("สร้างหมวดหมู่ใหม่", "", name -> {
                            if (!cats.contains(name)) cats.add(name);
                            moveTo(app, name);
                        });
                    }
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void moveTo(AppEntry app, String cat) {
        if (cat.equals(work.get(app.key))) return;
        work.put(app.key, cat);
        changed = true;
        rebuild();
        Toast.makeText(this, "ย้าย " + app.label + " → " + cat, Toast.LENGTH_SHORT).show();
    }

    private void askRename(String oldName) {
        askName("เปลี่ยนชื่อโฟลเดอร์", oldName, newName -> {
            if (newName.equals(oldName)) return;
            if (cats.contains(newName)) {
                Toast.makeText(this, "มีโฟลเดอร์ชื่อนี้อยู่แล้ว ใช้ \"ย้าย\" เพื่อรวมแอปแทน", Toast.LENGTH_LONG).show();
                return;
            }
            int idx = cats.indexOf(oldName);
            if (idx >= 0) cats.set(idx, newName);
            for (Map.Entry<String, String> e : work.entrySet()) {
                if (oldName.equals(e.getValue())) e.setValue(newName);
            }
            changed = true;
            rebuild();
        });
    }

    interface NameCallback {
        void onName(String name);
    }

    private void askName(String title, String initial, NameCallback cb) {
        final EditText edit = new EditText(this);
        edit.setText(initial);
        edit.setHint("ชื่อหมวดหมู่ เช่น งานบริษัท");
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(Ui.inputBox(this, edit))
                .setPositiveButton("ตกลง", (d, w) -> {
                    String name = edit.getText() == null ? "" : edit.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "กรุณาใส่ชื่อ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (name.length() > 40) name = name.substring(0, 40);
                    if (name.equals(UNSORTED)) {
                        Toast.makeText(this, "ชื่อนี้ใช้ไม่ได้", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    cb.onName(name);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void askAutoReset() {
        if (!loaded) return;
        new AlertDialog.Builder(this)
                .setTitle("จัดหมวดหมู่อัตโนมัติใหม่ทั้งหมด?")
                .setMessage("ทุกแอปจะกลับไปใช้หมวดที่ระบบเสนอ และชื่อโฟลเดอร์จะกลับเป็นค่าเริ่มต้น "
                        + "(ยังไม่บันทึกจนกว่าจะกด \"ยืนยัน\")")
                .setPositiveButton("จัดใหม่", (d, w) -> {
                    work.clear();
                    for (AppEntry a : apps) work.put(a.key, a.suggested);
                    cats.clear();
                    ensureCategories();
                    changed = true;
                    rebuild();
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void askConfirm() {
        if (!loaded || apps.isEmpty()) return;
        Map<String, Integer> counts = usedCounts();
        StringBuilder sb = new StringBuilder();
        sb.append("จะจัดแอป ").append(apps.size()).append(" แอป เป็น ")
                .append(counts.size()).append(" โฟลเดอร์:\n\n");
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            sb.append("• ").append(e.getKey()).append(" (").append(e.getValue()).append(")\n");
        }
        sb.append("\nแก้ไขภายหลังได้เสมอ และจะไม่ลบหรือถอนการติดตั้งแอปใดๆ");

        new AlertDialog.Builder(this)
                .setTitle("ยืนยันการจัดระเบียบ")
                .setMessage(sb.toString())
                .setPositiveButton("ยืนยันและจัดระเบียบ", (d, w) -> save())
                .setNegativeButton("กลับไปแก้ไข", null)
                .show();
    }

    private void save() {
        List<String> finalCats = new ArrayList<>(usedCounts().keySet());
        Map<String, String> finalAssign = new HashMap<>();
        for (AppEntry a : apps) {
            String c = work.get(a.key);
            if (c != null && finalCats.contains(c)) finalAssign.put(a.key, c);
        }
        store.save(finalCats, finalAssign);
        setResult(RESULT_OK);
        finish();
    }

    private void askCancel() {
        if (!changed) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("ออกโดยไม่บันทึก?")
                .setMessage("การแก้ไขในหน้านี้จะไม่ถูกบันทึก")
                .setPositiveButton("ออก", (d, w) -> {
                    setResult(RESULT_CANCELED);
                    finish();
                })
                .setNegativeButton("อยู่ต่อ", null)
                .show();
    }
}
