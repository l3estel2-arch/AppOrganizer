package com.thai.apporganizer;

import android.graphics.drawable.Drawable;

/** ข้อมูลแอป 1 รายการที่มีไอคอนบนหน้าจอ */
public final class AppEntry {
    /** คีย์ไม่ซ้ำ: package/activity */
    public final String key;
    public final String packageName;
    public final String activityName;
    public final String label;
    public final Drawable icon;
    /** หมวดหมู่ที่ระบบเสนอให้อัตโนมัติ */
    public final String suggested;

    public AppEntry(String key, String packageName, String activityName,
                    String label, Drawable icon, String suggested) {
        this.key = key;
        this.packageName = packageName;
        this.activityName = activityName;
        this.label = label;
        this.icon = icon;
        this.suggested = suggested;
    }
}
