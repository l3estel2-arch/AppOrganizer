package com.thai.apporganizer;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

/** ตัวช่วยสร้างหน้าตา UI (สร้างด้วยโค้ดทั้งหมด ไม่พึ่งไฟล์ layout) */
final class Ui {

    static final int BG = 0xFFF4F1EA;
    static final int CARD = 0xFFFFFFFF;
    static final int ACCENT = 0xFF2E6B5E;
    static final int ACCENT_SOFT = 0xFFE3EEEA;
    static final int TEXT = 0xFF1F2421;
    static final int MUTED = 0xFF6B6F6A;
    static final int LINE = 0xFFE2DDD3;
    static final int BADGE = 0xFFC8553D;

    private Ui() {
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable round(int fill, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static Drawable pressable(Drawable base) {
        return new RippleDrawable(ColorStateList.valueOf(0x22000000), base, null);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTextColor(primary ? 0xFFFFFFFF : ACCENT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(dp(c, 44));
        b.setMinimumHeight(dp(c, 44));
        b.setPadding(dp(c, 16), 0, dp(c, 16), 0);
        b.setSingleLine(true);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setGravity(Gravity.CENTER);
        b.setStateListAnimator(null);
        GradientDrawable bg = round(primary ? ACCENT : ACCENT_SOFT, dp(c, 22));
        b.setBackground(pressable(bg));
        return b;
    }

    /** ช่องพิมพ์ชื่อ (ใส่กรอบระยะขอบให้สวยใน dialog) */
    static FrameLayout inputBox(Context c, EditText edit) {
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        edit.setSingleLine(true);
        edit.setSelectAllOnFocus(true);
        FrameLayout box = new FrameLayout(c);
        int p = dp(c, 20);
        box.setPadding(p, dp(c, 8), p, 0);
        box.addView(edit);
        return box;
    }

    @SuppressWarnings("deprecation")
    static void setupWindow(Activity a) {
        Window w = a.getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController ic = w.getInsetsController();
            if (ic != null) {
                int flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                ic.setSystemBarsAppearance(flags, flags);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    /** เว้นระยะไม่ให้เนื้อหาไปทับแถบสถานะ/แถบนำทาง (รองรับ Android 15 แบบเต็มจอ) */
    @SuppressWarnings("deprecation")
    static void applyInsets(View v, final int padH, final int padTop, final int padBottom) {
        v.setPadding(padH, padTop, padH, padBottom);
        v.setOnApplyWindowInsetsListener((view, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = i.left;
                t = i.top;
                r = i.right;
                b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(padH + l, padTop + t, padH + r, padBottom + b);
            return insets;
        });
    }

    /** สำเนาไอคอน เพื่อใช้หลายที่พร้อมกันได้โดยไม่รบกวนกัน */
    static Drawable copyIcon(Context c, Drawable d) {
        if (d == null) return null;
        Drawable.ConstantState cs = d.getConstantState();
        return cs != null ? cs.newDrawable(c.getResources()).mutate() : d;
    }
}
