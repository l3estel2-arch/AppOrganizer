package com.thai.apporganizer;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** สแกนแอปทั้งหมดที่มีไอคอนบนหน้าจอ (ทำงานใน background thread) */
public final class AppRepository {

    private AppRepository() {
    }

    public static List<AppEntry> scan(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> infos;
        try {
            infos = pm.queryIntentActivities(intent, 0);
        } catch (RuntimeException e) {
            infos = new ArrayList<>();
        }

        String self = context.getPackageName();
        Map<String, AppEntry> map = new LinkedHashMap<>();
        for (ResolveInfo ri : infos) {
            ActivityInfo ai = ri.activityInfo;
            if (ai == null || ai.packageName == null || ai.name == null) continue;
            if (self.equals(ai.packageName)) continue;

            String key = ai.packageName + "/" + ai.name;
            if (map.containsKey(key)) continue;

            String label;
            try {
                CharSequence cs = ri.loadLabel(pm);
                label = cs == null ? "" : cs.toString().trim();
            } catch (RuntimeException e) {
                label = "";
            }
            if (label.isEmpty()) label = ai.packageName;

            Drawable icon;
            try {
                icon = ri.loadIcon(pm);
            } catch (RuntimeException e) {
                icon = null;
            }
            if (icon == null) icon = pm.getDefaultActivityIcon();

            String suggested = Categorizer.suggest(ai.packageName, label, ai.applicationInfo);
            map.put(key, new AppEntry(key, ai.packageName, ai.name, label, icon, suggested));
        }

        List<AppEntry> result = new ArrayList<>(map.values());
        final Collator collator = Collator.getInstance(Locale.forLanguageTag("th-TH"));
        Collections.sort(result, (a, b) -> collator.compare(a.label, b.label));
        return result;
    }
}
