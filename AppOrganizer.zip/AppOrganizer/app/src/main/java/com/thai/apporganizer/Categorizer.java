package com.thai.apporganizer;

import android.content.pm.ApplicationInfo;

import java.util.Locale;

/**
 * เสนอหมวดหมู่ให้แอปอัตโนมัติ
 * ลำดับการตัดสิน: (1) ระบบระบุว่าเป็นเกม (2) คำสำคัญในชื่อแพ็กเกจ/ชื่อแอป
 * (3) หมวดหมู่ที่ผู้พัฒนาแอปประกาศไว้ (4) แอประบบ -> เครื่องมือ (5) อื่นๆ
 */
public final class Categorizer {

    public static final String FOOD = "อาหารและเดลิเวอรี่";
    public static final String FINANCE = "การเงินและธนาคาร";
    public static final String MEDIA = "วิดีโอและเพลง";
    public static final String PHOTO = "ภาพถ่ายและกล้อง";
    public static final String SHOPPING = "ช้อปปิ้ง";
    public static final String SOCIAL = "โซเชียลและแชท";
    public static final String TRAVEL = "เดินทางและแผนที่";
    public static final String WORK = "งานและเอกสาร";
    public static final String NEWS = "ข่าวและการอ่าน";
    public static final String HEALTH = "สุขภาพและออกกำลังกาย";
    public static final String EDUCATION = "การศึกษา";
    public static final String GAMES = "เกม";
    public static final String TOOLS = "เครื่องมือและระบบ";
    public static final String OTHER = "อื่นๆ";

    /** ลำดับโฟลเดอร์เริ่มต้น */
    public static final String[] DEFAULT_ORDER = {
            SOCIAL, FINANCE, SHOPPING, FOOD, TRAVEL, MEDIA, PHOTO,
            WORK, NEWS, HEALTH, EDUCATION, GAMES, TOOLS, OTHER
    };

    /** กฎคำสำคัญ (ตัวพิมพ์เล็ก) ตรวจตามลำดับ เจอข้อแรกที่ตรงก็ใช้ข้อนั้น */
    private static final String[][] RULES = {
            {FOOD, "lineman", "line man", "foodpanda", "grabfood", "robinhood", "7-eleven", "7eleven",
                    "allonline", "mcdonald", "kfc", "starbucks", "pizza", "burger", "food", "อาหาร",
                    "delivery", "cafe", "restaurant"},
            {FINANCE, "bank", "ธนาคาร", "kplus", "k plus", "kbank", "scb", "ktb", "krungthai", "bualuang",
                    "com.bbl", "krungsri", "ttb", "gsb", "mymo", "baac", "uob", "cimb", "kkp", "truemoney",
                    "wallet", "paotang", "เป๋าตัง", "pay", "finance", "invest", "stock", "settrade",
                    "crypto", "bitkub", "binance", "insurance", "ประกัน", "finnomena", "dime", "เงิน"},
            {MEDIA, "youtube", "netflix", "spotify", "joox", "tiktok", "musically", "zhiliaoapp",
                    "disney", "hbo", "primevideo", "amazon.avod", "viu", "wetv", "iqiyi", "trueid",
                    "monomax", "bilibili", "twitch", "soundcloud", "music", "video", "player", "podcast",
                    "radio", "เพลง", "หนัง"},
            {PHOTO, "camera", "photo", "gallery", "snapseed", "lightroom", "picsart", "canva", "vsco",
                    "capcut", "meitu", "b612", "faceapp", "remini", "picture", "กล้อง", "รูป"},
            {SHOPPING, "shopee", "lazada", "amazon", "ebay", "aliexpress", "temu", "shein", "makro",
                    "lotus", "bigc", "central", "nocnoc", "powerbuy", "ikea", "shop", "ช้อป"},
            {SOCIAL, "facebook", "messenger", "instagram", "whatsapp", "telegram", "twitter", "threads",
                    "discord", "snapchat", "wechat", "tencent.mm", "viber", "signal", "reddit", "linkedin",
                    "pinterest", "kakao", "chat", "แชท"},
            {TRAVEL, "grab", "bolt", "uber", "maps", "waze", "agoda", "booking", "traveloka", "airasia",
                    "thaiairways", "nokair", "airline", "trip", "airbnb", "klook", "bts", "mrt", "railway",
                    "muvmi", "taxi", "navigation", "transit", "hotel", "แผนที่", "เดินทาง"},
            {WORK, "office", "excel", "powerpoint", "docs", "sheets", "slides", "drive", "dropbox",
                    "onedrive", "notion", "slack", "teams", "zoom", "meet", "gmail", "outlook", "mail",
                    "calendar", "keep", "evernote", "onenote", "notes", "trello", "asana", "pdf",
                    "scanner", "acrobat", "wps", "เอกสาร"},
            {NEWS, "news", "ข่าว", "thairath", "dailynews", "matichon", "khaosod", "bbc", "cnn",
                    "kindle", "meb", "ookbee", "manga", "comic", "webtoon", "flipboard", "medium",
                    "book", "หนังสือ", "นิยาย"},
            {HEALTH, "health", "fitness", "workout", "mohpromt", "หมอพร้อม", "hospital", "โรงพยาบาล",
                    "clinic", "doctor", "medical", "strava", "garmin", "zepp", "sleep", "yoga", "calorie",
                    "diet", "running", "สุขภาพ"},
            {EDUCATION, "education", "learn", "school", "duolingo", "classroom", "course", "khan",
                    "quizlet", "dictionary", "english", "study", "tutor", "udemy", "coursera", "longdo",
                    "เรียน", "ภาษา"},
            {GAMES, "game", "supercell", "garena", "roblox", "mojang", "minecraft", "pubg", "tencent.ig",
                    "mobile.legends", "moonton", "freefire", "nintendo", "com.ea.", "com.king.", "rovio",
                    "mihoyo", "hoyoverse", "genshin", "netmarble", "gameloft", "playrix", "เกม"},
            {TOOLS, "settings", "calculator", "calc", "clock", "files", "filemanager", "file manager",
                    "manager", "cleaner", "vpn", "browser", "chrome", "firefox", "opera", "brave",
                    "microsoft.emmx", "keyboard", "launcher", "flashlight", "weather", "translate",
                    "authenticator", "password", "backup", "security", "antivirus", "dialer", "contacts",
                    "messaging", "sms", "com.android.vending", "store", "recorder", "compass", "remote",
                    "wifi", "bluetooth", "ตั้งค่า", "เครื่องคิดเลข", "นาฬิกา", "อากาศ"},
    };

    private Categorizer() {
    }

    public static String suggest(String packageName, String label, ApplicationInfo app) {
        String p = packageName == null ? "" : packageName.toLowerCase(Locale.ROOT);
        String l = label == null ? "" : label.toLowerCase(Locale.ROOT).trim();

        if (app != null && isGame(app)) {
            return GAMES;
        }
        // LINE (แชท) ต้องตรวจแยก เพราะคำว่า "line" สั้นเกินไปจะไปตรงกับ online/airline
        if (p.startsWith("jp.naver.line.") || l.equals("line")) {
            return SOCIAL;
        }
        for (String[] rule : RULES) {
            for (int i = 1; i < rule.length; i++) {
                String kw = rule[i];
                if (p.contains(kw) || l.contains(kw)) {
                    return rule[0];
                }
            }
        }
        if (app != null) {
            String byCategory = fromDeclaredCategory(app.category);
            if (byCategory != null) {
                return byCategory;
            }
            if ((app.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
                return TOOLS;
            }
        }
        return OTHER;
    }

    @SuppressWarnings("deprecation")
    private static boolean isGame(ApplicationInfo app) {
        return app.category == ApplicationInfo.CATEGORY_GAME
                || (app.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
    }

    private static String fromDeclaredCategory(int category) {
        switch (category) {
            case ApplicationInfo.CATEGORY_AUDIO:
            case ApplicationInfo.CATEGORY_VIDEO:
                return MEDIA;
            case ApplicationInfo.CATEGORY_IMAGE:
                return PHOTO;
            case ApplicationInfo.CATEGORY_SOCIAL:
                return SOCIAL;
            case ApplicationInfo.CATEGORY_NEWS:
                return NEWS;
            case ApplicationInfo.CATEGORY_MAPS:
                return TRAVEL;
            case ApplicationInfo.CATEGORY_PRODUCTIVITY:
                return WORK;
            case ApplicationInfo.CATEGORY_ACCESSIBILITY:
                return TOOLS;
            default:
                return null;
        }
    }
}
