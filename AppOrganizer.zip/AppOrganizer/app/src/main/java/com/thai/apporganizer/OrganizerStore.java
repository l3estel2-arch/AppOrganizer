package com.thai.apporganizer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** เก็บผลการจัดหมวดหมู่ที่ผู้ใช้ยืนยันแล้ว */
public final class OrganizerStore {

    private static final String PREFS = "organizer";
    private static final String K_APPLIED = "applied";
    private static final String K_CATEGORIES = "categories";
    private static final String K_ASSIGN = "assignments";

    private final SharedPreferences sp;

    public OrganizerStore(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isApplied() {
        return sp.getBoolean(K_APPLIED, false);
    }

    public List<String> loadCategories() {
        List<String> out = new ArrayList<>();
        String raw = sp.getString(K_CATEGORIES, null);
        if (raw == null) return out;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String s = arr.optString(i, "").trim();
                if (!s.isEmpty() && !out.contains(s)) out.add(s);
            }
        } catch (JSONException ignored) {
            // ข้อมูลเสีย -> ถือว่ายังไม่มีหมวดหมู่
        }
        return out;
    }

    public Map<String, String> loadAssignments() {
        Map<String, String> out = new HashMap<>();
        String raw = sp.getString(K_ASSIGN, null);
        if (raw == null) return out;
        try {
            JSONObject obj = new JSONObject(raw);
            Iterator<String> it = obj.keys();
            while (it.hasNext()) {
                String k = it.next();
                String v = obj.optString(k, "");
                if (!v.isEmpty()) out.put(k, v);
            }
        } catch (JSONException ignored) {
            // ข้อมูลเสีย -> ถือว่ายังไม่ได้จัด
        }
        return out;
    }

    public void save(List<String> categories, Map<String, String> assignments) {
        JSONArray arr = new JSONArray();
        for (String c : categories) arr.put(c);
        JSONObject obj = new JSONObject();
        try {
            for (Map.Entry<String, String> e : assignments.entrySet()) {
                obj.put(e.getKey(), e.getValue());
            }
        } catch (JSONException ignored) {
            // key เป็น String เสมอ จึงไม่เกิดขึ้นจริง
        }
        sp.edit()
                .putBoolean(K_APPLIED, true)
                .putString(K_CATEGORIES, arr.toString())
                .putString(K_ASSIGN, obj.toString())
                .apply();
    }

    /** หาหมวดของแอป: ตรง key ก่อน ถ้าไม่เจอ (เช่นแอปอัปเดต) ใช้ชื่อแพ็กเกจเดียวกัน */
    public static String lookup(Map<String, String> assignments, AppEntry app) {
        String v = assignments.get(app.key);
        if (v != null) return v;
        String prefix = app.packageName + "/";
        for (Map.Entry<String, String> e : assignments.entrySet()) {
            if (e.getKey().startsWith(prefix)) return e.getValue();
        }
        return null;
    }
}
